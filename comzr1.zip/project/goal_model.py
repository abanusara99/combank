from typing import Optional
from dataclasses import dataclass

@dataclass
class Goal:
    id: str
    name: str
    target_amount: float
    current_amount: float
    icon: Optional[str] = None

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "targetAmount": self.target_amount,
            "currentAmount": self.current_amount,
            "icon": self.icon
        }