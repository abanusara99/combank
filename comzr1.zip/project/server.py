from http.server import HTTPServer, BaseHTTPRequestHandler
import json
from urllib.parse import urlparse, parse_qs
from typing import Dict, Any, Optional

# Simulated database for demonstration
# In a real implementation, this would use pymongo to connect to MongoDB
class MockDatabase:
    def __init__(self):
        self.goals = [
            {
                "id": "1",
                "name": "Emergency Fund",
                "targetAmount": 5000,
                "currentAmount": 2500,
                "icon": "💰"
            },
            {
                "id": "2",
                "name": "New Car",
                "targetAmount": 20000,
                "currentAmount": 5000,
                "icon": "🚗"
            }
        ]

    def get_goals(self):
        return self.goals

class RequestHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        self.db = MockDatabase()
        super().__init__(*args, **kwargs)

    def do_GET(self):
        parsed_path = urlparse(self.path)
        
        if parsed_path.path == '/api/goals':
            self.handle_goals()
        else:
            self.send_error(404, "Path not found")

    def handle_goals(self):
        goals = self.db.get_goals()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps({"goals": goals}).encode())

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

def run_server(port: int = 8000):
    server_address = ('', port)
    httpd = HTTPServer(server_address, RequestHandler)
    print(f"Server running on port {port}")
    httpd.serve_forever()

if __name__ == '__main__':
    run_server()