const express = require('express');
const cors = require('cors');
const { User, Goal, Account, Transaction, Tag } = require('./models');

const app = express();

// Enable CORS
app.use(cors());
app.use(express.json());

// Mock database
const mockData = {
  users: [
    new User("1", "John Doe", "john@example.com")
  ],
  goals: [
    new Goal("1", "Emergency Fund", 5000, "2024-12-31", "1"),
    new Goal("2", "New Car", 20000, "2025-06-30", "1")
  ],
  accounts: [
    new Account("1", "1234567890", "Savings Account", "SAVINGS")
  ],
  transactions: [
    new Transaction("1", "DEPOSIT", "Initial deposit", 2500, "2023-01-01T00:00:00Z", "1", "1"),
    new Transaction("2", "DEPOSIT", "Car fund deposit", 5000, "2023-01-02T00:00:00Z", "2", "1")
  ],
  tags: [
    new Tag("1", "Savings"),
    new Tag("2", "Vehicle")
  ]
};

// Update relationships
mockData.users[0].goalIds = ["1", "2"];
mockData.users[0].accountIds = ["1"];
mockData.users[0].transactionIds = ["1", "2"];

mockData.goals[0].transactionIds = ["1"];
mockData.goals[0].tagIds = ["1"];
mockData.goals[0].icon = "💰";

mockData.goals[1].transactionIds = ["2"];
mockData.goals[1].tagIds = ["2"];
mockData.goals[1].icon = "🚗";

// Calculate balances
mockData.goals.forEach(goal => {
  goal.balance = mockData.transactions
    .filter(t => t.goalId === goal.id)
    .reduce((sum, t) => sum + t.amount, 0);
});

// API Routes
app.get('/api/goals', (req, res) => {
  res.json({ goals: mockData.goals });
});

app.get('/api/users/:userId/goals', (req, res) => {
  const userGoals = mockData.goals.filter(goal => goal.userId === req.params.userId);
  res.json({ goals: userGoals });
});

app.get('/api/users/:userId/transactions', (req, res) => {
  const userTransactions = mockData.transactions.filter(t => t.userId === req.params.userId);
  res.json({ transactions: userTransactions });
});

app.get('/api/goals/:goalId/transactions', (req, res) => {
  const goalTransactions = mockData.transactions.filter(t => t.goalId === req.params.goalId);
  res.json({ transactions: goalTransactions });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});