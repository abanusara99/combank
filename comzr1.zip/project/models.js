// Data models based on the provided schema
class User {
  constructor(id, name, email) {
    this.id = id;
    this.name = name;
    this.email = email;
    this.applicationIds = [];
    this.accountIds = [];
    this.goalIds = [];
    this.transactionIds = [];
  }
}

class Goal {
  constructor(id, name, targetAmount, targetDate, userId) {
    this.id = id;
    this.name = name;
    this.targetAmount = targetAmount;
    this.targetDate = targetDate;
    this.balance = 0;
    this.transactionIds = [];
    this.tagIds = [];
    this.icon = null;
    this.userId = userId;
  }
}

class Account {
  constructor(id, number, name, accountType) {
    this.id = id;
    this.number = number;
    this.name = name;
    this.balance = 0;
    this.accountType = accountType;
    this.transactionIds = [];
  }
}

class Transaction {
  constructor(id, type, description, amount, datetime, goalId, userId) {
    this.id = id;
    this.type = type;
    this.description = description;
    this.amount = amount;
    this.datetime = datetime;
    this.goalId = goalId;
    this.tagIds = [];
    this.userId = userId;
  }
}

class Tag {
  constructor(id, name) {
    this.id = id;
    this.name = name;
  }
}

module.exports = {
  User,
  Goal,
  Account,
  Transaction,
  Tag
};